package score;

import index.Index;

public class TFIDFScoringFun implements TermScoringFun {

	Index _index; 
	
	@Override
	public void init(Index s) {
		_index = s; 
	}

	@Override
	public double scoreToken(String term, int freq) {
		double _s; //create the score to return 
		double _documentFrequency = (double)_index.getDocumentFreq(term);  //get the document frquency 
		if(_documentFrequency != 0.00) { //check whether the document frequency is 0, so the score cannot be infinity 
			_s = (1 + Math.log10(freq)) * (Math.log10((double)_index.getDocSource().getNumDocs()/ _documentFrequency));
			return _s;
		} else {
			return 0; //if the document frequency is 0, then the score for this file is 0 
		}
	}

}
