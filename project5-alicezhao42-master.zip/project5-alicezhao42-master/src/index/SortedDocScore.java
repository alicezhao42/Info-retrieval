package index;


public class SortedDocScore extends DocScore implements Comparable {
	
	public SortedDocScore(double score, int i, String ds) {
		super(score,i,ds); 
	}

	public SortedDocScore(DocScore ds) {
		super(ds);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compareTo(Object o) {
	//	if (o != null) { 
			if(((DocScore) o).getScore() > this.getScore() ) { //return 1 if the score of the object is bigger than the score of this 
				return 1; 
			} else if (((DocScore) o).getScore() < this.getScore() ) { ////return -1 if the score of the object is less than the score of this
				return -1; 
			} else {
				return this.getContent().compareTo(((DocScore) o).getContent()); 
			} 
	//	} else {
	//	}
	}
	
	@Override 
	public boolean equals(Object o) {
		if(((DocScore) o).getScore() == this.getScore() && ((DocScore) o).getContent().equals(this.getContent())) { //if the scores AND the content is the same then the object is the same 
			return true; 
		}
		return false; //return false if the content or score is different 
	}
	
	@Override 
	public int hashCode() {
		//combine content 
//		int h = 0; 
//		h = 31*h + (int)_score; 
//		h = 31*h + _docID; 
//		h = 31*h +_content.hashCode(); 
//		return h; 
		return 0; 
	}

}
