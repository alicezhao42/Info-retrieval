package index;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

import io.DocSource;
import io.StaticDocSource;
import score.TFIDFScoringFun;
import score.TermScoringFun;
import tokenizer.IndexingTokenizer;
import tokenizer.Tokenizer;

public class InvertedIndex extends Index{

	private HashMap<String, HashMap<Integer,Integer>> _index; 
	private HashMap<String, Integer> _docFreq;
	int _count; 
	 
	private ArrayList<String> _arrayOfWords = new ArrayList<String>();
	
	
	public InvertedIndex(DocSource doc_source, Tokenizer tokenizer, TermScoringFun scoring) {
		super(doc_source, tokenizer, scoring);
		_index = new HashMap<String, HashMap<Integer,Integer>>(); //initialize the hashMap to hold the frequency of words in each document 
		_docFreq = new HashMap<String, Integer>(); //initialize the hashMap to hold the frequency of each word in each document 
	}

	@Override
	public void buildIndex() { 

		for (int i = 0; i < _docSource.getNumDocs(); i++) { //loop over documents 
			_arrayOfWords = _tokenizer.tokenize(_docSource.getDoc(i)); //tokenize the document and store the terms in a new array 
			
			for (String _words: _arrayOfWords) { //loop over the tokens (words) 
				if(! _index.containsKey(_words)) { //check if _index contains the word already 
					HashMap<Integer,Integer> _inside = new HashMap<Integer,Integer>();
					_inside.put(i,1); 
					_index.put(_words,_inside); //if _index doesn't contain the word already, add in a hashMap containing the word, and frequency of 1 
					_docFreq.put(_words, 1); 

				} else {
					HashMap<Integer,Integer> _con = new HashMap<Integer,Integer>();
					_con = _index.get(_words); //get the hashMap associated with the word in _index 
					if (!_con.containsKey(i)) { //if the hashMap associated with the word in _index does not contain the document number 
						HashMap<Integer,Integer> _newTerm = _index.get(_words); //make a new term that replicates the old hashMap associated with that term in _index 
						_newTerm.put(i, 1);  //add a new term containing the document id number and frequency of 1 to the replicated copy of the hashMap associated with the word 
						_index.put(_words, _newTerm); //add updated hashMap to _index 
					} else { //if the hashMap in _index that is associated with the term does contain that document ID number in its keys 
						HashMap<Integer,Integer> _ne = _index.get(_words); //make copy of the hashMap associated with the term in _index 
						_ne.put(i, _con.get(i) +1); //add one to the existing term associated with that word and ID number 
						_index.put(_words, _ne); //add the new and updated hashMap into _index, replacing the old one 
					}
				}
			}
		} 
		
		for(String key: _docFreq.keySet()) { //run through all the words in _docFreq
			_docFreq.put(key, _index.get(key).size()); //put the words and the document frequency into _docFreq 
		}
		
		System.out.println("Done building index.");
	} 
	
	public String toString() {
		StringBuilder sb = new StringBuilder(); 
		sb.append("{"); 
		for(String i : _index.keySet()) {
			sb.append(i); 
			sb.append("="); 
			sb.append(_index.get(i)); 
			sb.append(", "); 
		}
		return sb.toString(); 
	}

	@Override
	public Integer getDocumentFreq(String term) {
		//one line method 
		if(_docFreq.containsKey(term)) {//check if document frequency contains this term and if it does return the value associated with this term 
			return _docFreq.get(term);
		} else {
			return 0; //if _docFreq doesn't contain the term then return 0 
		}
	}

	@Override
	public ArrayList<DocScore> getSortedSearchResults(String query) {

		_arrayOfWords = _tokenizer.tokenize(query);  //tokenize query 
		ArrayList<DocScore> _doc = new ArrayList<DocScore>(); //create an arrayList to store the docScores 
		TreeSet<DocScore> _tree = new TreeSet<DocScore>(); //create a treeSet to 
		HashMap <Integer,Double> hs = new HashMap<Integer,Double>();  
		double _preScore = 0; 

		for(String qu: _arrayOfWords) { //run through the terms in tokenized query 
			for (int i = 0; i < _docSource.getNumDocs(); i++) { //get document number 
				double _scores = 0; //set score to 0, reset when looped to next document 
				if(_index.containsKey(qu)) {  //check if _index contains the word
					
					if(_index.get(qu).containsKey(i)) { //check if the hashMap associated with the word contains that document id number 
						if(!(hs.containsKey(i))) {
						_scores = _scoring.scoreToken(qu, (int) _index.get(qu).get(i)); //score the word 
						hs.put(i, _scores); 
						}
						else {
							_preScore = hs.get(i); 
							_scores = _scoring.scoreToken(qu, (int) _index.get(qu).get(i)); //score the word 
							hs.put(i,_preScore + _scores);
						}
					}
				}
//				else { //if _index does not contain the word then move on to the next word 
//				 break; 
//				}
			}	
				for(Integer j: hs.keySet()) {
					SortedDocScore sds = new SortedDocScore(hs.get(j), j, _docSource.getDoc(j)); //create a new sortedDocScore 
					_tree.add(sds); 
				}
		} _doc.addAll(_tree); //add of the docScores in the TreeSet to the arrayList (should be in order) 
		return _doc; //return the arrayList 
	}
}
