package test;
import index.SortedDocScore;

public class TestSortedDocScore {
	public static void main(String[] args) {
		SortedDocScore doc1 = new SortedDocScore(1.0,0,"The quick brown for jumps overthe lazy dog"); 
		SortedDocScore doc1Copy = new SortedDocScore(doc1); 
		SortedDocScore doc2 = new SortedDocScore(0.9,1, "Amazingly few discothesques provide jukeboxes"); 
		System.out.println(doc1.compareTo(doc2));
		System.out.println("Does doc1 equal doc1Copy? " + 
				(doc1.equals(doc1Copy) ? "yes" : "no")
				);
		System.out.println("Does doc1 equal doc2? " +
				(doc1.equals(doc2) ? "yes" : "no")
				);
		System.out.println("Doc1 hash code: " + doc1.hashCode()); //check algorithms and data structures lectures 
		System.out.println("Doc2 hash code: " + doc2.hashCode()); //To find out how to implement hasCode(); 
	}
}
