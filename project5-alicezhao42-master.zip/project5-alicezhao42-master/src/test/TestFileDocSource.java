package test;
import soln.io.FileDocSource;
import tokenizer.IndexingTokenizer;
import io.FileFinder; 


public class TestFileDocSource {

	public static void main(String[] args) {
		FileDocSource fds = new FileDocSource("files"); 
		System.out.println(FileFinder.GetAllFiles("files"));
		System.out.println("FileDocSource found " + fds.getNumDocs() + " files"); 
		System.out.println("Example document: "); 
		System.out.println(fds.getDoc(0)); 
		IndexingTokenizer it = new IndexingTokenizer(); 
		for (int i = 0; i<10; i++ ) {
			System.out.println(it.tokenize(fds.getDoc(i)));
		}
	}
}
