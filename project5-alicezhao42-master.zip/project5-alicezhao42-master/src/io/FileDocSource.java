package io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FileDocSource extends DocSource {
	
	ArrayList<File> _files = new ArrayList<File>(); 
	
	public FileDocSource(String location){
		//uses FileFinder to find all of the documents in 'location' 
		_files = FileFinder.GetAllFiles(location); 
	}

	@Override
	public int getNumDocs() {
		return _files.size(); //return the size of my arrayList that stores the files 
	}

	@Override
	public String getDoc(int id) {
		StringBuilder sb = new StringBuilder(); //create new stringBuilder 
		try { //try to append line to sb
			String line; 
			BufferedReader cin = new BufferedReader(new FileReader(_files.get(id)));
			while((line = cin.readLine()) != null) { //check whether the line is null 
				sb.append(line + " ");  
			}
			cin.close(); //close the reader 
		} catch (IOException e) {	
			
		}
		return sb.toString(); //return the string conversion of the stringBuilder 
	}
}
