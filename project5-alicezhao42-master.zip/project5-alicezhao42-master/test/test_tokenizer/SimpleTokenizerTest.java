package test_tokenizer;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import index.SortedDocScore;
import score.TFIDFScoringFun;
import score.TFScoringFun;
import soln.io.FileDocSource;
import tokenizer.Tokenizer;
import tokenizer.IndexingTokenizer;
import tokenizer.SimpleTokenizer;

public class SimpleTokenizerTest {

	@Test
	public void testTokenize() {
		Tokenizer tok = new SimpleTokenizer();
		ArrayList<String> tokens = tok.tokenize("A state-of-the-art product.");
		assertEquals("Failed lowercase", "a", tokens.get(0));
		assertEquals("Failed hyphen test", "state-of-the-art", tokens.get(1));
		assertEquals("Failed simple token", "product", tokens.get(2));
	}
	
	@Test
	public void testIndexingTokenizer() { //first case 
		Tokenizer _inTo = new IndexingTokenizer(); //create new indexingTokenizer
		ArrayList<String> tokens = _inTo.tokenize("CISE Research Instrumentation"); //tokenize the string 
		assertEquals("Pass lowercase", "cise", tokens.get(0)); //check whether the answers match 
		assertEquals("Pass indexing token", "research", tokens.get(1));
		assertEquals(" indexing token", "instrumentation", tokens.get(2));
		
	}
	
	@Test
	public void testSortedDocScore() {
		SortedDocScore d1 = new SortedDocScore(20.0, 0,"The quick brown for jumps overthe lazy dog"); //create a new sortedDocScore 
		SortedDocScore d2 = new SortedDocScore(17.0, 1,"Just for fun test cases"); //create a new sortedDocScore 
		SortedDocScore d1Copy = new SortedDocScore(d1); //create a copy of the first sortedDocScore 
		assertEquals("Passed", "true",  d1.equals(d1Copy)); //check whether it matches 
		assertEquals("failed", "false", d1.equals(d2));
	}
	
	@Test
	public void testgetNumDocs() {
		FileDocSource fds = new FileDocSource("files"); //create new fileDocScoure
		String _num = Integer.toString(fds.getNumDocs()); //get the number of documents in the file and convert it into a string 
		assertEquals("Passed getNumDocs", "10", _num); //check if answers match 
	}
	
	@Test
	public void testTFIDFScoring() {
		TFIDFScoringFun tf = new TFIDFScoringFun(); //create new TFIFDScoring 
		HashMap<String, HashMap<Integer,Integer>> _index = new HashMap<String,HashMap<Integer,Integer>>(); //set variables for the _docfreq and _index 
		HashMap<String, Integer> _docFreq = new HashMap<String, Integer>();  
		HashMap<Integer,Integer> inside = new HashMap<Integer,Integer>(); 
		inside.put(1, 1); 
		_index.put("cat", inside); 
		_docFreq.put("cat", 1); 
		String scoring = Double.toString(tf.scoreToken("cat", 1)); //calculate the score using TFIDFScoringFun 
		assertEquals("Passed Scoring", "2", scoring); //check if answers are the same 
	}
	
	@Test
	public void testTFScoringFun() {
		TFScoringFun tfScoring = new TFScoringFun(); //create new TFScoringFun
		String scoring = Double.toString(tfScoring.scoreToken("cat", 1)); //score it and convert it to String 
		assertEquals("Passed Scoring", "2", scoring); //check if answers are the same 
	}

	@Test
	public void failAlways() {
		//Thread.sleep(3000);
		fail("This always fails");
	}
}
